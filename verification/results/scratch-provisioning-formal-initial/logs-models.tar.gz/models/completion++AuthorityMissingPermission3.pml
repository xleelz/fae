// num_comm_params=0
// num_mand_comm_params=0
// num_opt_comm_params=0

// git_link=https://github.com//blob///Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go#L3
typedef Chandef {
	chan sync = [0] of {bool};
	chan enq = [0] of {bool};
	chan deq = [0] of {bool,bool};
	chan sending = [0] of {bool};
	chan rcving = [0] of {bool};
	chan closing = [0] of {bool};
	int size = 0;
	int num_msgs = 0;
	bool closed = false;
}



init { 
	chan child_AuthorityMissingPermission30 = [1] of {int}->
	run AuthorityMissingPermission3(child_AuthorityMissingPermission30)->
	child_AuthorityMissingPermission30?0->
stop_process:skip
}

proctype AuthorityMissingPermission3(chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	chan child_AnonymousAuthorityMissingPermission942 = [1] of {int}->
	chan child_AnonymousAuthorityMissingPermission841 = [1] of {int}->
	chan child_AnonymousAuthorityMissingPermission740 = [1] of {int}->
	Chandef committed_ch->
	Chandef permitted_ch->
	Chandef authenticated_ch->
	run sync_monitor(authenticated_ch)->
	run sync_monitor(permitted_ch)->
	run sync_monitor(committed_ch)->
	run AnonymousAuthorityMissingPermission74(authenticated_ch,permitted_ch,committed_ch,child_AnonymousAuthorityMissingPermission740)->
	run receiver(child_AnonymousAuthorityMissingPermission740)->
	run AnonymousAuthorityMissingPermission84(authenticated_ch,permitted_ch,committed_ch,child_AnonymousAuthorityMissingPermission841)->
	run receiver(child_AnonymousAuthorityMissingPermission841)->
	run AnonymousAuthorityMissingPermission94(authenticated_ch,permitted_ch,committed_ch,child_AnonymousAuthorityMissingPermission942)->
	run receiver(child_AnonymousAuthorityMissingPermission942)->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:10:2 */
	:: committed_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:10:2 */->
	:: committed_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:10:2 */ -> 
		committed_ch.rcving!false
	fi->
	stop_process: skip->
	child!0
}
proctype AnonymousAuthorityMissingPermission74(Chandef authenticated_ch;Chandef permitted_ch;Chandef committed_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:7:12 */
	:: authenticated_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:7:12 */
	:: authenticated_ch.sync!false -> 
		authenticated_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:7:12 */
	fi->
	stop_process: skip->
	child!0
}
proctype AnonymousAuthorityMissingPermission84(Chandef authenticated_ch;Chandef permitted_ch;Chandef committed_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:8:12 */
	:: authenticated_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:8:12 */->
	:: authenticated_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:8:12 */ -> 
		authenticated_ch.rcving!false
	fi->
	stop_process: skip->
	child!0
}
proctype AnonymousAuthorityMissingPermission94(Chandef authenticated_ch;Chandef permitted_ch;Chandef committed_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:9:12 */
	:: permitted_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:9:12 */->
	:: permitted_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:9:12 */ -> 
		permitted_ch.rcving!false
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:9:24 */
	:: committed_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:9:24 */
	:: committed_ch.sync!false -> 
		committed_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.yP7R9c/negative/authority.go:9:24 */
	fi->
	stop_process: skip->
	child!0
}

 /* ================================================================================== */
 /* ================================================================================== */
 /* ================================================================================== */ 
proctype async_monitor(Chandef ch) {
do
:: true ->
if
:: ch.closed -> 
end: if
  :: ch.num_msgs > 0 -> // cannot send on closed channel
    end4: if
    :: ch.enq!false-> // cannot send on closed channel
    :: ch.closing!true -> // cannot close twice a channel
    :: ch.rcving?false->
    :: ch.sending!false -> // sending state of channel (closed)
    :: ch.deq!true,ch.num_msgs -> 
  		 ch.num_msgs = ch.num_msgs - 1
    fi->
  :: else ->    end5: if
    :: ch.enq!false-> // cannot send on closed channel
    :: ch.closing!true -> // cannot close twice a channel
    :: ch.rcving?false->
    :: ch.sending!false -> // sending state of channel (closed)
    :: ch.sync!true-> 
    fi->
  fi->
:: else ->
	if
	:: ch.num_msgs == ch.size ->
		end1: if
		  :: ch.deq!false,ch.num_msgs ->
		    ch.num_msgs = ch.num_msgs - 1
		  :: ch.closing!false -> // closing the channel
		    ch.closed = true
		   :: ch.rcving?false ->
 		    ch.sending!true->
		fi->
	:: ch.num_msgs == 0 -> 
end2:		if
		:: ch.enq!true -> // a message has been received
			ch.num_msgs = ch.num_msgs + 1
		:: ch.closing!false -> // closing the channel
			ch.closed = true
		:: ch.rcving?false ->
 		    ch.sending!true->
		fi->
		:: else -> 
		end3: if
		  :: ch.enq!true->
		     ch.num_msgs = ch.num_msgs + 1
		  :: ch.deq!false,ch.num_msgs->
		     ch.num_msgs = ch.num_msgs - 1
		  :: ch.closing!false -> // closing the channel
		     ch.closed = true
		  :: ch.rcving?false ->
 		    ch.sending!true->
		fi->
	fi->
fi->
od->
}

proctype sync_monitor(Chandef ch) {
do
:: true->
if
:: ch.closed ->
end: if
  :: ch.enq!false-> // cannot send on closed channel
  :: ch.closing!true -> // cannot close twice a channel
  :: ch.sending!false -> // sending state of channel (closed)
  :: ch.rcving?false->
  :: ch.sync!true-> // can always receive on a closed chan
  fi->
:: else -> 
end1: if
    :: ch.rcving?false ->
       ch.sending!true->
    :: ch.closing!false ->
      ch.closed = true
    fi->
fi->
od->
stop_process: skip
}

proctype receiver(chan c) {
c?0
}

