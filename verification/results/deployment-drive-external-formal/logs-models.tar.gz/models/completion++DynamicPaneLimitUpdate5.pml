// num_comm_params=0
// num_mand_comm_params=0
// num_opt_comm_params=0

// git_link=https://github.com//blob///Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go#L5
typedef Chandef {
	chan sync = [0] of {bool};
	chan enq = [0] of {bool};
	chan deq = [0] of {bool,bool};
	chan sending = [0] of {bool};
	chan rcving = [0] of {bool};
	chan closing = [0] of {bool};
	int size = 0;
	int num_msgs = 0;
	bool closed = false;
}



init { 
	chan child_DynamicPaneLimitUpdate50 = [1] of {int}->
	run DynamicPaneLimitUpdate5(child_DynamicPaneLimitUpdate50)->
	child_DynamicPaneLimitUpdate50?0->
stop_process:skip
}

proctype DynamicPaneLimitUpdate5(chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	chan child_paneRetry181 = [1] of {int}->
	chan child_paneUpdate170 = [1] of {int}->
	Chandef done_ch->
	Chandef retired_ch->
	Chandef updated_ch->
	Chandef lock_ch->
	

	if
	:: 1 > 0 -> 
		lock_ch.size = 1->
		run async_monitor(lock_ch)
	:: else -> 
		run sync_monitor(lock_ch)
	fi->
	run sync_monitor(updated_ch)->
	run sync_monitor(retired_ch)->
	

	if
	:: 2 > 0 -> 
		done_ch.size = 2->
		run async_monitor(done_ch)
	:: else -> 
		run sync_monitor(done_ch)
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:10:2 */
	:: lock_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:10:2 */
	:: lock_ch.sync!false -> 
		lock_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:10:2 */
	fi->
	run paneUpdate17(lock_ch,updated_ch,done_ch,child_paneUpdate170)->
	run receiver(child_paneUpdate170)->
	run paneRetry18(lock_ch,updated_ch,retired_ch,done_ch,child_paneRetry181)->
	run receiver(child_paneRetry181)->
	retired_ch.closing?closed /* Close	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:13:2 */->
	assert(!closed) /* Close	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:13:2 */->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:14:2 */
	:: done_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:14:2 */->
	:: done_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:14:2 */ -> 
		done_ch.rcving!false
	fi->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:15:2 */
	:: done_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:15:2 */->
	:: done_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:15:2 */ -> 
		done_ch.rcving!false
	fi->
	stop_process: skip->
	child!0
}
proctype paneUpdate17(Chandef lock_ch;Chandef updated_ch;Chandef done_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:49 */
	:: lock_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:49 */->
	:: lock_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:49 */ -> 
		lock_ch.rcving!false
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:57 */
	:: lock_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:57 */
	:: lock_ch.sync!false -> 
		lock_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:57 */
	fi->
	updated_ch.closing?closed /* Close	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:68 */->
	assert(!closed) /* Close	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:68 */->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:84 */
	:: done_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:84 */
	:: done_ch.sync!false -> 
		done_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:17:84 */
	fi->
	stop_process: skip->
	child!0
}
proctype paneRetry18(Chandef lock_ch;Chandef updated_ch;Chandef retired_ch;Chandef done_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:19:2 */
	:: updated_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:19:2 */->
	:: updated_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:19:2 */ -> 
		updated_ch.rcving!false
	fi->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:20:2 */
	:: retired_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:20:2 */->
	:: retired_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:20:2 */ -> 
		retired_ch.rcving!false
	fi->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:21:2 */
	:: lock_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:21:2 */->
	:: lock_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:21:2 */ -> 
		lock_ch.rcving!false
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:22:2 */
	:: lock_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:22:2 */
	:: lock_ch.sync!false -> 
		lock_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:22:2 */
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:23:2 */
	:: done_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:23:2 */
	:: done_ch.sync!false -> 
		done_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.lrsiQ2/source/dynamic_panes.go:23:2 */
	fi->
	stop_process: skip->
	child!0
}

 /* ================================================================================== */
 /* ================================================================================== */
 /* ================================================================================== */ 
proctype async_monitor(Chandef ch) {
do
:: true ->
if
:: ch.closed -> 
end: if
  :: ch.num_msgs > 0 -> // cannot send on closed channel
    end4: if
    :: ch.enq!false-> // cannot send on closed channel
    :: ch.closing!true -> // cannot close twice a channel
    :: ch.rcving?false->
    :: ch.sending!false -> // sending state of channel (closed)
    :: ch.deq!true,ch.num_msgs -> 
  		 ch.num_msgs = ch.num_msgs - 1
    fi->
  :: else ->    end5: if
    :: ch.enq!false-> // cannot send on closed channel
    :: ch.closing!true -> // cannot close twice a channel
    :: ch.rcving?false->
    :: ch.sending!false -> // sending state of channel (closed)
    :: ch.sync!true-> 
    fi->
  fi->
:: else ->
	if
	:: ch.num_msgs == ch.size ->
		end1: if
		  :: ch.deq!false,ch.num_msgs ->
		    ch.num_msgs = ch.num_msgs - 1
		  :: ch.closing!false -> // closing the channel
		    ch.closed = true
		   :: ch.rcving?false ->
 		    ch.sending!true->
		fi->
	:: ch.num_msgs == 0 -> 
end2:		if
		:: ch.enq!true -> // a message has been received
			ch.num_msgs = ch.num_msgs + 1
		:: ch.closing!false -> // closing the channel
			ch.closed = true
		:: ch.rcving?false ->
 		    ch.sending!true->
		fi->
		:: else -> 
		end3: if
		  :: ch.enq!true->
		     ch.num_msgs = ch.num_msgs + 1
		  :: ch.deq!false,ch.num_msgs->
		     ch.num_msgs = ch.num_msgs - 1
		  :: ch.closing!false -> // closing the channel
		     ch.closed = true
		  :: ch.rcving?false ->
 		    ch.sending!true->
		fi->
	fi->
fi->
od->
}

proctype sync_monitor(Chandef ch) {
do
:: true->
if
:: ch.closed ->
end: if
  :: ch.enq!false-> // cannot send on closed channel
  :: ch.closing!true -> // cannot close twice a channel
  :: ch.sending!false -> // sending state of channel (closed)
  :: ch.rcving?false->
  :: ch.sync!true-> // can always receive on a closed chan
  fi->
:: else -> 
end1: if
    :: ch.rcving?false ->
       ch.sending!true->
    :: ch.closing!false ->
      ch.closed = true
    fi->
fi->
od->
stop_process: skip
}

proctype receiver(chan c) {
c?0
}

