// num_comm_params=0
// num_mand_comm_params=0
// num_opt_comm_params=0

// git_link=https://github.com//blob///Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go#L3
typedef Chandef {
	chan sync = [0] of {bool};
	chan enq = [0] of {bool};
	chan deq = [0] of {bool,bool};
	chan sending = [0] of {bool};
	chan rcving = [0] of {bool};
	chan closing = [0] of {bool};
	int size = 0;
	int num_msgs = 0;
	bool closed = false;
}



init { 
	chan child_ScratchRemovalWaitsForStopAndBackup30 = [1] of {int}->
	run ScratchRemovalWaitsForStopAndBackup3(child_ScratchRemovalWaitsForStopAndBackup30)->
	child_ScratchRemovalWaitsForStopAndBackup30?0->
stop_process:skip
}

proctype ScratchRemovalWaitsForStopAndBackup3(chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	chan child_AnonymousScratchRemovalWaitsForStopAndBackup952 = [1] of {int}->
	chan child_AnonymousScratchRemovalWaitsForStopAndBackup841 = [1] of {int}->
	chan child_AnonymousScratchRemovalWaitsForStopAndBackup740 = [1] of {int}->
	Chandef removed_ch->
	Chandef backup_ch->
	Chandef stopped_ch->
	run sync_monitor(stopped_ch)->
	run sync_monitor(backup_ch)->
	run sync_monitor(removed_ch)->
	run AnonymousScratchRemovalWaitsForStopAndBackup74(stopped_ch,backup_ch,removed_ch,child_AnonymousScratchRemovalWaitsForStopAndBackup740)->
	run receiver(child_AnonymousScratchRemovalWaitsForStopAndBackup740)->
	run AnonymousScratchRemovalWaitsForStopAndBackup84(stopped_ch,backup_ch,removed_ch,child_AnonymousScratchRemovalWaitsForStopAndBackup841)->
	run receiver(child_AnonymousScratchRemovalWaitsForStopAndBackup841)->
	run AnonymousScratchRemovalWaitsForStopAndBackup95(backup_ch,removed_ch,stopped_ch,child_AnonymousScratchRemovalWaitsForStopAndBackup952)->
	run receiver(child_AnonymousScratchRemovalWaitsForStopAndBackup952)->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:10:2 */
	:: removed_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:10:2 */->
	:: removed_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:10:2 */ -> 
		removed_ch.rcving!false
	fi->
	stop_process: skip->
	child!0
}
proctype AnonymousScratchRemovalWaitsForStopAndBackup74(Chandef stopped_ch;Chandef backup_ch;Chandef removed_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:7:14 */
	:: stopped_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:7:14 */
	:: stopped_ch.sync!false -> 
		stopped_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:7:14 */
	fi->
	stop_process: skip->
	child!0
}
proctype AnonymousScratchRemovalWaitsForStopAndBackup84(Chandef stopped_ch;Chandef backup_ch;Chandef removed_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:8:14 */
	:: stopped_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:8:14 */->
	:: stopped_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:8:14 */ -> 
		stopped_ch.rcving!false
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:8:25 */
	:: backup_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:8:25 */
	:: backup_ch.sync!false -> 
		backup_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:8:25 */
	fi->
	stop_process: skip->
	child!0
}
proctype AnonymousScratchRemovalWaitsForStopAndBackup95(Chandef backup_ch;Chandef removed_ch;Chandef stopped_ch;chan child) {
	bool closed-> 
	bool ok-> 
	int i->
	bool state = true->
	int num_msgs->
	

	if /* Rcv	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:9:14 */
	:: backup_ch.deq?state,num_msgs /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:9:14 */->
	:: backup_ch.sync?state /* 	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:9:14 */ -> 
		backup_ch.rcving!false
	fi->
	

	if /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:9:24 */
	:: removed_ch.enq?ok -> 
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:9:24 */
	:: removed_ch.sync!false -> 
		removed_ch.sending?ok->
		assert(ok) /* Send	/Users/lbethay/workplace/fae/.tools/gomela-pinned/fae-run.g2aXab/source/scratch.go:9:24 */
	fi->
	stop_process: skip->
	child!0
}

 /* ================================================================================== */
 /* ================================================================================== */
 /* ================================================================================== */ 
proctype async_monitor(Chandef ch) {
do
:: true ->
if
:: ch.closed -> 
end: if
  :: ch.num_msgs > 0 -> // cannot send on closed channel
    end4: if
    :: ch.enq!false-> // cannot send on closed channel
    :: ch.closing!true -> // cannot close twice a channel
    :: ch.rcving?false->
    :: ch.sending!false -> // sending state of channel (closed)
    :: ch.deq!true,ch.num_msgs -> 
  		 ch.num_msgs = ch.num_msgs - 1
    fi->
  :: else ->    end5: if
    :: ch.enq!false-> // cannot send on closed channel
    :: ch.closing!true -> // cannot close twice a channel
    :: ch.rcving?false->
    :: ch.sending!false -> // sending state of channel (closed)
    :: ch.sync!true-> 
    fi->
  fi->
:: else ->
	if
	:: ch.num_msgs == ch.size ->
		end1: if
		  :: ch.deq!false,ch.num_msgs ->
		    ch.num_msgs = ch.num_msgs - 1
		  :: ch.closing!false -> // closing the channel
		    ch.closed = true
		   :: ch.rcving?false ->
 		    ch.sending!true->
		fi->
	:: ch.num_msgs == 0 -> 
end2:		if
		:: ch.enq!true -> // a message has been received
			ch.num_msgs = ch.num_msgs + 1
		:: ch.closing!false -> // closing the channel
			ch.closed = true
		:: ch.rcving?false ->
 		    ch.sending!true->
		fi->
		:: else -> 
		end3: if
		  :: ch.enq!true->
		     ch.num_msgs = ch.num_msgs + 1
		  :: ch.deq!false,ch.num_msgs->
		     ch.num_msgs = ch.num_msgs - 1
		  :: ch.closing!false -> // closing the channel
		     ch.closed = true
		  :: ch.rcving?false ->
 		    ch.sending!true->
		fi->
	fi->
fi->
od->
}

proctype sync_monitor(Chandef ch) {
do
:: true->
if
:: ch.closed ->
end: if
  :: ch.enq!false-> // cannot send on closed channel
  :: ch.closing!true -> // cannot close twice a channel
  :: ch.sending!false -> // sending state of channel (closed)
  :: ch.rcving?false->
  :: ch.sync!true-> // can always receive on a closed chan
  fi->
:: else -> 
end1: if
    :: ch.rcving?false ->
       ch.sending!true->
    :: ch.closing!false ->
      ch.closed = true
    fi->
fi->
od->
stop_process: skip
}

proctype receiver(chan c) {
c?0
}

